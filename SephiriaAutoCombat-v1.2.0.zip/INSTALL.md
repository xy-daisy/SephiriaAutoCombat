# Sephiria Auto Combat（自动索敌 / 自动攻击）

版本 **v1.2.0** · 插件 GUID `com.sephiria.autocombat`

进入战斗后自动锁定**距离最近的敌人**，并自动朝它挥动**当前武器**进行普攻。目标一直在变近变远，锁定也会跟着变 —— **不是**锁住一个就不放。

## 本版（v1.2.0）改了什么

**索敌从「粘性锁定」改成「始终锁最近」**

v1.1.0 只在**手上没有目标时**才扫一次敌人列表，抓到谁就一直锁谁，直到它死亡 / 消失 / 跑出范围。结果就是：一只远处的残血怪先被你锁上，之后哪怕有小怪已经贴到你脸上，角色还是朝着那只远处的挥 —— 除非它死掉。

现在**每次扫描都重新取最近的敌人**，只要另一个敌人比当前目标更近，锁定立刻转过去。

- 扫描间隔 = `ScanInterval`（默认 0.1 秒），也就是锁定跟随最近的刷新频率。
- **保留**了"目标跑出范围后不马上丢"的宽限（`LostDistanceFactor` / `ReleaseSeconds`），但它现在的职责只是**防止在边缘反复丢锁/捡锁**，不会阻止更近的敌人抢走锁定。
- **`PreferBoss` 默认改成 `false`**。它原来默认 `true`，会让 boss 抢在"最近的敌人"之前 —— 那和本版规则冲突。

> **从 v1.1.0 升级请注意**：旧的配置文件里 `PreferBoss` 是被写成 `true` 的，那个值会覆盖"永远锁最近"的规则。请把它改成 `false`，或者直接删掉 `BepInEx\config\com.sephiria.autocombat.cfg` 让游戏重新生成一份。

**新增 `SwitchHysteresis`（默认 `0`）**

纯粹的防抖动阈值，只在两个敌人距离**差不多**时才有意义：

- `0`（默认）= 纯最近。谁更近就锁谁，完全按规则来。
- 比如填 `1.5` = 新目标必须比当前目标近**至少 1.5 格**才抢得走锁定。

如果一群怪挤在一起、锁定在两三个之间来回跳得你头晕，就把它调大一点。它**永远不会**让锁定粘在一个明显更远的敌人身上。

## v1.1.0 修的问题（仍然有效）

**1. 打完怪之后还在原地不停挥砍 —— 已修**

这是 v1.0.0 的一个真 bug，根因不在索敌，而在**开火键被按住了没松**。

游戏里每一把武器都是「按住连击」设计：武器内部有一个 `isAttackButtonDown` 开关，只要它为真、且上一刀挥完了，游戏就会**立刻再起一刀** —— 跟周围有没有敌人完全无关。而只有 `AttackButtonUp` 会把那个开关关掉。

v1.0.0 在"目标消失"和"关掉自动索敌"这两条路径上直接 `return` 了，一次松手都没发出去，于是开关永久为真 → 空房间里无限挥砍。

现在：**所有停止攻击的路径都收口到一个函数**，并且加了一层看门狗 —— 每帧重发松手，直到游戏自己确认收到为止（游戏在角色不能移动时会静默忽略松手指令，单发一次是不够的）。主机 / 离线模式下还有最后一道兜底：超过 2 秒仍松不开就直接把那个开关清掉。

**2. 攻击范围太小、所有武器共用一个值 —— 已修**

现在**按当前装备的武器**决定攻击触发范围。内置默认：

| 武器 | 触发范围（世界单位） |
|---|---|
| 匕首 `Dagger` | 4.0 |
| 剑盾 `SwordAndShield` / 魔像 `Golem` | 5.0 |
| 武士刀 `Katana` | 6.0 |
| 大剑 `GreatSword` / 长杖 `Staff` | 6.5 |
| 弓 `Bow` | 15.0 |
| 弩 `Crossbow` | 16.0 |

而且**锁敌半径也会跟着武器走**（不再固定 10），不然弓锁不住自己射程内的敌人。
想自己调可以用 `[Range] RangeOverrides`，例如 `WeaponSimple_Bow=18; WeaponSimple_Katana=7`。

**3. 顺带：出招节奏也按武器分开（`AttackMode = Auto`）**

- **近战 / 弩**：按住不放，让游戏自己的连击循环接管 —— 这就是原版按住攻击键的手感，连段更顺。
- **弓**：按住直到**蓄力条拉满**再松手，箭才射得出去。之前"按住 0.15 秒就松手"对弓来说**根本射不出箭**。

## 功能

- **自动索敌**：索敌范围内出现敌对单位时，自动锁定**最近**的那个，并持续跟随 —— 有更近的敌人就换。
- **自动攻击**：走**游戏原版的武器攻击链路**（普攻、连招、冲刺攻击），伤害、动画、连段判定、服务器校验都是原版的。
- **自动面向**：会让角色朝向锁定的目标。

## 快捷键

| 按键 | 作用 |
|---|---|
| **F5** | 自动索敌 开 / 关 |
| **F6** | 自动攻击 开 / 关 |

两个键都可以在配置文件里改成别的键。**没有总开关**，想彻底停用请卸载本 mod（或把两个开关都关掉）。

> 自动攻击依赖锁定目标：F5 关掉之后没有目标，F6 开着也不会攻击（但会把手上的按键干净地松开）。

## 重要：这个 mod **不会**做这些事

- **不会自动走位**。移动完全由你自己控制。目标超出当前武器的攻击范围时会自动停手，等你走近再继续打。
- **不会自动放技能 / 魔法**，只用当前装备的武器普攻。
- **不会自动喝药、捡东西、切武器。**
- **不会改你的存档或角色数值**，也不写任何网络同步变量。

## 前置条件

必须先装好 **BepInEx 6（Unity Mono x64）**。

判断是否已装：打开游戏根目录，同时存在下面三项即已装好：

```
winhttp.dll
doorstop_config.ini
BepInEx\
```

如果你装过带 BepInEx 的整合包（例如 Sephiria Together 的 with-BepInEx 版本），那就已经具备了，直接跳到安装步骤。

## 安装

1. 关闭游戏。
2. 把压缩包里的 `BepInEx` 文件夹**直接拖进游戏根目录**（即 `steamapps\common\Sephiria\`），提示合并时选"是"。
3. 启动游戏。

装好后应该长这样：

```
steamapps\common\Sephiria\
├─ BepInEx\
│  ├─ plugins\SephiriaAutoCombat.dll
│  └─ config\com.sephiria.autocombat.cfg
```

## 卸载

删掉 `BepInEx\plugins\SephiriaAutoCombat.dll` 即可（配置文件可以留着，也可以一并删掉）。

## 配置

配置文件：`BepInEx\config\com.sephiria.autocombat.cfg`
改完保存，重进游戏生效。压缩包里的 cfg 只是**默认值备份**；如果它和你机器上的不一致，以游戏实际生成的那份为准。

### Keys

| 配置项 | 默认 | 说明 |
|---|---|---|
| `ToggleAutoTargetKey` | `F5` | 自动索敌开关的键，填 Input System 的键名（如 `F5`、`G`） |
| `ToggleAutoAttackKey` | `F6` | 自动攻击开关的键 |

### Targeting（索敌）

| 配置项 | 默认 | 说明 |
|---|---|---|
| `TargetRadius` | `10` | 索敌半径的**下限**（世界单位）。实际半径取 `max(这个值, 武器范围 × LockRadiusMargin + LockRadiusSlack)` |
| `SwitchHysteresis` | `0` | **防抖死区**。`0` = 纯最近，谁近锁谁。填 `1.5` = 新目标要比当前目标近 1.5 格以上才抢得走。只在两个敌人距离接近时才起作用 |
| `LostDistanceFactor` | `1.4` | 保留倍数：目标要跑出 `索敌半径 × 此值` 才开始考虑放弃，避免在边缘反复丢锁/捡锁。**不会**阻止更近的敌人抢锁 |
| `ReleaseSeconds` | `1.5` | 目标跑出保留范围后，还留着锁定多久。丢掉之后下一次扫描按"最近"重新选 |
| `ScanInterval` | `0.1` | 每隔多久重新扫一次目标。这也就是**锁定跟随最近的刷新频率**（瞄准和攻击仍是每帧执行） |
| `RequireInBattle` | `false` | `true` = 只有游戏标记你「战斗中」时才锁敌；`false` = 索敌半径内有敌人就锁 |
| `ExcludeDummy` | `true` | 是否排除训练假人 / 稻草人（它们会把「战斗中」标志拉起来） |
| `PreferBoss` | `false` | `true` = 有 boss 就优先锁 boss（**会覆盖"永远锁最近"**）。`false` = 一律锁最近的 |
| `LogTargetChanges` | `true` | 锁定 / 切换 / 放弃目标时打日志 |

### Range（按武器决定攻击范围）

| 配置项 | 默认 | 说明 |
|---|---|---|
| `AutoWeaponRange` | `true` | 按装备的武器解析攻击范围（推荐）。`false` = 不走内置武器表 |
| `MeleeRadius` | `5` | 内置表里没有的近战武器，用这个兜底 |
| `RangedRadius` | `14` | 内置表里没有的远程武器，用这个兜底 |
| `WeaponRadiusScale` | `1` | 整体倍率，`1` = 不缩放 |
| `ApplyWeaponRangeStat` | `true` | 同时按你角色的 `WeaponRange` 属性缩放范围（游戏自己算近战判定框就是这么算的：`1 + 属性/100`）。对硬覆盖的 `AttackRadius` 不生效 |
| `RangeOverrides` | （空） | 逐武器覆盖，格式 `武器类名=范围`，多条用 `;` 隔开。例：`WeaponSimple_Bow=18; WeaponSimple_Katana=7`。武器类名会在你换武器时打进日志 |
| `LockRadiusMargin` | `1.15` | 锁敌半径 = `max(TargetRadius, 攻击范围 × 此值 + LockRadiusSlack)` |
| `LockRadiusSlack` | `1` | 在上面基础上额外加的固定距离。想锁得更"早"就调大，想锁得更"紧"就调小甚至填负数 |
| `LogWeaponProfile` | `true` | 换武器时打一行「武器 / 节奏 / 攻击范围 / 锁敌范围」，方便你调表 |

### Attack（出招节奏）

| 配置项 | 默认 | 说明 |
|---|---|---|
| `AttackMode` | `Auto` | `Auto` = 按武器自动（推荐）；`Hold` = 一直按住；`Repeat` = 固定节奏「按 → 松」 |
| `PressDuration` | `0.15` | 仅 `Repeat`：每次按住的时长（秒） |
| `PressInterval` | `0.25` | 仅 `Repeat`：两次开始按键之间的间隔（秒） |
| `AttackRadius` | `0` | **硬覆盖**：填正数则所有武器都用这个距离。`0` = 关闭（推荐，让 `[Range]` 生效）。保留它是为了兼容旧配置 |
| `AttackOnlyWithWeapon` | `true` | 手上没武器时不去按攻击键 |
| `ChargeReleaseRatio` | `0.999` | 蓄力武器（弓）：蓄力到这个比例就松手。`0.999` = 拉满 |
| `ChargeTimeoutSeconds` | `2.5` | 蓄力武器：按钮最多按住多久。读不到蓄力进度时也用这个值当按住时长 —— 保证任何情况下都不会一直按着 |
| `PulseRecycleSeconds` | `0.25` | 蓄力武器：松手放箭后，隔多久开始下一次蓄力 |

### Aim

| 配置项 | 默认 | 说明 |
|---|---|---|
| `ForceFacing` | `true` | 让角色朝向锁定目标。如果出现瞄准表现异常可以关掉（关掉后攻击方向依然正确，只是转身不那么跟手） |

### Safety

| 配置项 | 默认 | 说明 |
|---|---|---|
| `YieldToGame` | `true` | 对话 / 过场动画时让位，不抢输入 |
| `PauseWhenInputBlocked` | `true` | 游戏屏蔽角色输入时（读盘、菜单、剧情）暂停 |
| `PauseWhenUiOpen` | `true` | 打开游戏内面板时暂停 |
| `OnlyLocalPlayer` | `true` | 只操作本地玩家角色 |
| `ReleaseRetrySeconds` | `2` | 游戏超过这么久还没接受松手指令（角色不能移动时它会静默忽略），就升级处理：打警告，能强制清位就强制清 |
| `HardReleaseFallback` | `true` | 最后的兜底：直接清掉游戏内部的 `isFireButtonDown` / `isAttackButtonDown` 开关。**只有主机 / 离线模式可以**（纯客户端不拥有那份状态，只能靠不停重发松手） |

### General

| 配置项 | 默认 | 说明 |
|---|---|---|
| `AutoTargetEnabled` | `true` | 启动时自动索敌就是开的 |
| `AutoAttackEnabled` | `true` | 启动时自动攻击就是开的 |
| `HeartbeatSeconds` | `15` | 每隔多少秒打一行状态摘要（含当前武器和范围），`0` = 关闭 |
| `DebugLog` | `false` | 详细日志（每次扫描、每次按键、每次松手），排查问题用 |

### Diagnostics

| 配置项 | 默认 | 说明 |
|---|---|---|
| `LogWeaponProbe` | `false` | 每种武器首次装备时，打印它的攻击判定框尺寸等数据。只用来给内置范围表做标定；日常不用开 |

## 排错

日志文件：`BepInEx\LogOutput.log`

- **完全没反应**：
  1. 先在日志里搜 `Sephiria Auto Combat`，确认 mod 加载成功（会打印版本、开关状态、攻击模式）。
  2. 按 F5 / F6 看有没有 `Auto-target ON/OFF` 的日志。**没有**说明快捷键没生效（可能被别的 mod 占用，或者配置里键名写错了）—— 换一个键再试。
  3. 把 `DebugLog` 改成 `true`，再看是否出现 `Locked <敌人名>`。
- **打的不是我想要的那个敌人**：日志里搜 `Switched to` —— 每次换目标都会打一行 `Switched to X (dist ..., was Y)`。如果换得太频繁，把 `SwitchHysteresis` 调大（例如 `1.5`）；如果它迟迟不换，确认 `PreferBoss` 是 `false`。
- **打不到远处的敌人**：看日志里那行 `weapon <类名> kind=... attackRange=...`，这就是当前判定用的范围。想改就按上面 `[Range]` 那节调 `RangeOverrides`（把你日志里那个类名填进去）。
- **弓不射箭 / 一直拉不开**：日志里 `kind=ChargedRanged` 才是被识别成了蓄力武器。如果显示 `kind=Ranged` 说明你这把弓没有蓄力字段，那就应该按住即射；把日志发出来。
- **出现 `attack button was stuck held`** 警告：游戏在角色不能移动时忽略了松手指令，mod 已经重试 / 兜底清位了。如果反复出现请把日志发出来。
- **打完怪还会挥一两下**：这是"按住连击"的固有延迟（当前那一刀要挥完），不是没松手。日志里 `attack release` 之后就不会再起新刀了。
- **和别的 mod 冲突**：本 mod 只做了一个只读性质的 Harmony 补丁（`WeaponControllerSimple.Update` 的 Prefix），不修改任何返回值，冲突概率很低。如果怀疑冲突，把 `ForceFacing` 改成 `false` 再试。

## 已知限制

- **多人联机**：每个装了本 mod 的客户端各自控制自己的角色。攻击走的是游戏原版的服务器指令（`[Command]`），服务器会照常校验，别的玩家看不到任何异常。
  - 如果你是**纯客户端**（不是主机），游戏内部那个"按住"开关在服务器那一份实例上，客户端碰不到。mod 会用不停重发松手指令的方式修，这条路是有效的；但 `HardReleaseFallback` 那层兜底只在主机 / 离线生效，日志里会说明。
- **同时面对多个敌人时会来回换目标**：这是"始终锁最近"的固有结果。一群怪挤在一起、彼此距离又很接近时，目标可能在两三个之间跳。想让它"认准一个打"就把 `SwitchHysteresis` 调到 `1.5 ~ 3`。
- **锁敌半径会变远**：拿弓时锁敌半径会到 18 格左右，可能锁到墙后面另一个房间的敌人（游戏没有视线检查）。因为 mod 不走位，实际影响只是"朝向"和日志，但会浪费箭。想收窄请调 `LockRadiusMargin` / `LockRadiusSlack`（注意 `TargetRadius` 是**下限**，调它没用）。
- **内置范围是估值**：那张表按屏幕尺寸和武器分类推出来的，不是从游戏资产里读出的真实判定框。打开 `LogWeaponProbe` 跑几把武器，把日志发出来即可标定成实测值。
- **不会微调走位**：目标横向跑动时，攻击方向是在每次出招瞬间取的，所以极快速横移的敌人可能偶尔落空 —— 这是「不自动走位」这个前提的必然结果。
- **训练假人默认排除**，想打假人练手请把 `ExcludeDummy` 改成 `false`。

---

## English quick version

**Sephiria Auto Combat v1.2.0**

Auto-locks the **nearest** hostile enemy while in combat and drives the vanilla weapon
attack chain at it. It never moves your character, never casts skills and never writes
any SyncVar.

- **F5** toggles auto-targeting, **F6** toggles auto-attacking (change them under `[Keys]`).
- Requires **BepInEx 6 (Unity Mono x64)** already installed.
- Install: copy the bundled `BepInEx` folder into the game root and merge.
- Config: `BepInEx\config\com.sephiria.autocombat.cfg`
- Log: `BepInEx\LogOutput.log` (set `DebugLog = true` for detail).

**Changed in v1.2.0**

The lock is **no longer sticky**. v1.1.0 only scanned while nothing was locked, so the
first enemy it caught stayed the target until it died - even with something already in
your face. The scan now runs every `ScanInterval` (0.1s) and always re-picks the closest
hostile, so the lock moves to a closer enemy immediately.

- `PreferBoss` now defaults to `false` (it used to override "nearest"). If you are
  upgrading, set it to `false` in your existing cfg or delete the cfg file.
- New `SwitchHysteresis` (default `0` = pure nearest). Raise it to ~1.5-3 if a tight
  crowd of enemies makes the target flicker; it can never make the lock stick to
  something clearly farther away.

**Still fixed from v1.1.0**

1. *Attacking forever in an empty room.* Every vanilla weapon is built as "Hold To
   Attack": the weapon keeps an internal latch that its own update loop turns into a new
   swing every frame, and only `AttackButtonUp` clears it. v1.0.0 returned early on the
   "target lost" and "auto-target off" paths without ever releasing the button, so the
   latch stayed set. All stop paths now funnel through one release function, a watchdog
   re-sends the release until the game confirms it, and the host/offline mode can
   force-clear the latch as a last resort.

2. *One attack range for every weapon.* The trigger range is now derived from the
   equipped weapon (dagger 4.0, sword 5.0, katana 6.0, greatsword/staff 6.5, bow 15.0,
   crossbow 16.0 by default), and the lock radius follows it so a bow can lock on at its
   own reach. Override per weapon with `[Range] RangeOverrides`.

3. *Rhythm is per weapon now* (`AttackMode = Auto`): melee and crossbows hold the button
   (the game's own combo loop takes over), bows hold until the draw is full and then
   release - a 0.15s tap can never fire a bow.

Key settings: `[Targeting] SwitchHysteresis` (0 = pure nearest), `PreferBoss` (false),
`ScanInterval` (0.1), `TargetRadius` (10, a floor), `ExcludeDummy` (true);
`[Range] AutoWeaponRange` (true), `RangeOverrides` (empty), `LockRadiusMargin` (1.15);
`[Attack] AttackMode` (`Auto`), `AttackRadius` (0 = per weapon);
`[Safety] HardReleaseFallback` (true), `[Aim] ForceFacing` (true).

The only Harmony patch is a Prefix on `WeaponControllerSimple.Update` that points the
client-side aim at the locked target; disable it with `ForceFacing = false`.
